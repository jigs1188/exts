// =============================================================================
// MetaPrompt – Background Service Worker
// =============================================================================

// ── Keep-Alive (dual strategy) ──────────────────────────────────────────────
chrome.alarms.create('keepAlive', { periodInMinutes: 0.4 });
chrome.alarms.onAlarm.addListener(() => { /* heartbeat — keeps service worker alive */ });
chrome.runtime.onConnect.addListener((port) => { /* port keep-alive from content script */ });
chrome.runtime.onInstalled.addListener(() => chrome.alarms.create('keepAlive', { periodInMinutes: 0.4 }));
chrome.runtime.onStartup.addListener(() => chrome.alarms.create('keepAlive', { periodInMinutes: 0.4 }));

// ── Model Configuration ──────────────────────────────────────────────────────

// Ordered fallback lists per tier (newest/most capable first within tier)
const MODEL_TIERS = {
  auto:   ['gemini-2.0-flash', 'gemini-1.5-flash-latest', 'gemini-1.5-flash', 'gemini-1.5-pro', 'gemini-pro'],
  flash:  ['gemini-2.0-flash', 'gemini-1.5-flash-latest', 'gemini-1.5-flash', 'gemini-pro'],
  pro:    ['gemini-1.5-pro-latest', 'gemini-1.5-pro', 'gemini-2.0-flash'],
  latest: ['gemini-2.5-flash-preview-04-17', 'gemini-2.5-pro-preview', 'gemini-2.0-flash-exp', 'gemini-2.0-flash'],
};

// All models probed during discovery (newest first)
const ALL_KNOWN_MODELS = [
  { id: 'gemini-2.5-flash-preview-04-17', label: '2.5 Flash Preview', tier: 'latest' },
  { id: 'gemini-2.5-pro-preview',         label: '2.5 Pro Preview',   tier: 'latest' },
  { id: 'gemini-2.0-flash-exp',           label: '2.0 Flash Exp',     tier: 'latest' },
  { id: 'gemini-2.0-flash',               label: '2.0 Flash',         tier: 'flash'  },
  { id: 'gemini-1.5-flash-latest',        label: '1.5 Flash Latest',  tier: 'flash'  },
  { id: 'gemini-1.5-flash',               label: '1.5 Flash',         tier: 'flash'  },
  { id: 'gemini-1.5-pro-latest',          label: '1.5 Pro Latest',    tier: 'pro'    },
  { id: 'gemini-1.5-pro',                 label: '1.5 Pro',           tier: 'pro'    },
  { id: 'gemini-pro',                     label: 'Gemini Pro',        tier: 'flash'  },
];

// ── Message Handler ──────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'OPTIMIZE_PROMPT') {
    handleOptimization(request)
      .then(data => sendResponse({ success: true, data }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
  if (request.action === 'MODEL_DISCOVERY') {
    discoverModels(request.apiKey)
      .then(data => sendResponse({ success: true, data }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
});

// ── Model Discovery ──────────────────────────────────────────────────────────

async function discoverModels(apiKey) {
  const availability = {};
  for (const model of ALL_KNOWN_MODELS) {
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model.id}:generateContent?key=${apiKey}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: 'hi' }] }],
          generationConfig: { maxOutputTokens: 1 }
        })
      });
      // 404 = model doesn't exist. 200/400/429/403 = model exists (key/quota issue, not model issue)
      availability[model.id] = res.status !== 404;
    } catch (e) {
      availability[model.id] = false;
    }
    await new Promise(r => setTimeout(r, 150)); // small delay to avoid rate limits
  }
  return { availability, models: ALL_KNOWN_MODELS, timestamp: Date.now() };
}

// ── Technique System Instructions ────────────────────────────────────────────

function buildSystemInstruction(technique, userPrompt, history) {
  const ctx = history ? `### CONTEXT (Recent chat history)\n${history}\n\n` : '';

  if (technique === 'cot') {
    return `You are an expert Prompt Engineer specializing in Chain-of-Thought (CoT) prompting.

Rewrite the user's prompt so it forces the AI to reason step-by-step before answering.
The rewritten prompt MUST instruct the AI to:
1. Think through the problem stage by stage before giving an answer
2. Number each reasoning step clearly
3. Verify its conclusion before presenting the final result

STRICT RULES: Output ONLY the rewritten prompt. NO preamble. NO explanation. Start directly.

${ctx}### USER'S RAW PROMPT
"${userPrompt}"`;
  }

  if (technique === 'few_shot') {
    return `You are an expert Prompt Engineer specializing in Few-Shot prompting.

Rewrite the user's prompt to include 2-3 concrete, realistic examples (input→output pairs) BEFORE the actual task. This shows the AI exactly what format and quality is expected.

Structure:
1. Brief task description
2. Example 1: [input] → [output]
3. Example 2: [input] → [output]
4. "Now:" followed by the actual user request

STRICT RULES: Examples must be realistic and domain-specific, NOT placeholders. Output ONLY the rewritten prompt. NO preamble.

${ctx}### USER'S RAW PROMPT
"${userPrompt}"`;
  }

  if (technique === 'zero_shot') {
    return `You are an expert Prompt Engineer specializing in Zero-Shot structured prompting.

Rewrite the user's prompt as a clean, precise, structured instruction with these labeled sections:

**Role:** [specific expert — e.g. "Senior React Developer", NOT vague "coding expert"]
**Task:** [the exact task in one sentence]
**Constraints:** [rules, limits, requirements]
**Output Format:** [structure, length, format of expected response]

STRICT RULES: Be specific in every field. Output ONLY the structured prompt. NO preamble.

${ctx}### USER'S RAW PROMPT
"${userPrompt}"`;
  }

  if (technique === 'react') {
    return `You are an expert Prompt Engineer specializing in the ReAct (Reason + Act) prompting technique.

Rewrite the user's prompt so the AI follows this loop:
- **Thought:** Analyze what is needed and plan the approach
- **Action:** Take a specific concrete step (write, calculate, research, plan)
- **Observation:** Note the result
→ Repeat 2-4 cycles as needed
→ **Final Answer:** The complete result

The rewritten prompt should clearly instruct the AI to use this Thought/Action/Observation structure.

STRICT RULES: Output ONLY the rewritten prompt. NO preamble. NO explanation.

${ctx}### USER'S RAW PROMPT
"${userPrompt}"`;
  }

  if (technique === 'persona') {
    // Explicit Expert Persona (same quality as auto but always uses this technique)
    return buildPersonaInstruction(userPrompt, ctx);
  }

  // Default: 'auto' — Gemini decides the best technique
  return `You are an elite Prompt Engineering AI with mastery of all prompting techniques.

Silently analyze the user's raw prompt and determine which technique produces the BEST result:
- EXPERT PERSONA: Task needs specialized domain knowledge (coding, writing, science, strategy)
- CHAIN OF THOUGHT: Task involves logic, math, debugging, or multi-step reasoning
- FEW-SHOT: Task needs specific output format or creative structured content
- ZERO-SHOT DIRECT: Simple task that just needs clean, structured instructions
- ReAct: Multi-step research, planning, or investigation

Then apply the BEST technique and rewrite the prompt accordingly.

STRICT RULES:
1. Output ONLY the final rewritten prompt — NO meta-commentary like "I used CoT because..."
2. NO preamble like "Here is your optimized prompt"
3. Start the output DIRECTLY with the rewritten prompt content
4. Preserve ALL specific data, code, or details from the original

${ctx}### USER'S RAW PROMPT
"${userPrompt}"`;
}

function buildPersonaInstruction(userPrompt, ctx) {
  return `You are an elite Prompt Engineering AI specializing in Expert Persona prompting.

Analyze the user's request and derive the PERFECT specific expert persona for it. Then rewrite the prompt using that persona.

Rules for persona selection:
- Python data analysis → "Lead Data Scientist specializing in Pandas/Matplotlib"
- Web scraping → "Web Scraping Specialist with expertise in BeautifulSoup/Playwright"
- Game development → "Senior Game Engine Architect with Unity/Pygame expertise"
- NEVER use generic personas like "expert coder" or "helpful assistant"

The rewritten prompt must have: Persona, specific Requirements, and Output Format.

FEW-SHOT EXAMPLES:
Input: "make a snake game in python"
Output: Act as a Senior Python Game Developer with deep expertise in Pygame. Create a fully object-oriented Snake game. Requirements: OOP classes (Snake, Food, Game), score tracking, progressive speed, Game Over screen. Output: complete runnable code with comments.

Input: "explain recursion"
Output: Act as a Master CS Educator specializing in visual learning. Explain recursion to a complete beginner. Use the "Russian Nesting Dolls" analogy. Cover: base case, recursive case, call stack. Include a simple Python example. Output: structured explanation with diagrams described in text.

STRICT RULES: Output ONLY the rewritten prompt. NO preamble. NO explanation.

${ctx}### USER'S RAW PROMPT
"${userPrompt}"`;
}

// ── Core Optimization ────────────────────────────────────────────────────────

async function handleOptimization({ prompt, apiKey, history = '', model = 'auto', technique = 'auto' }) {
  const systemInstruction = buildSystemInstruction(technique, prompt, history);
  const modelList = MODEL_TIERS[model] || MODEL_TIERS.auto;

  let lastError = null;

  for (const modelId of modelList) {
    try {
      console.log(`[MetaPrompt] Trying ${modelId} | technique: ${technique}`);
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${modelId}:generateContent?key=${apiKey}`;

      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: systemInstruction }] }]
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        const errMsg = errData.error?.message || res.statusText;

        if (res.status === 404 || res.status === 400) {
          console.warn(`[MetaPrompt] ${modelId} unavailable (${res.status}). Trying next...`);
          lastError = new Error(`${modelId} not available`);
          continue;
        }
        throw new Error(errMsg); // 403, 429 etc — stop immediately
      }

      const data = await res.json();
      if (!data.candidates?.[0]?.content) throw new Error('Empty response from Gemini API');

      return data.candidates[0].content.parts[0].text.trim();

    } catch (error) {
      lastError = error;
      const isHardFail = ['quota', 'API key', 'permission', 'PERMISSION_DENIED', 'API_KEY_INVALID']
        .some(k => error.message.includes(k));
      if (isHardFail) throw error;
    }
  }

  throw lastError || new Error('All models in this tier failed. Try a different tier or check your API key.');
}
