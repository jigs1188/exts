// ── Constants ─────────────────────────────────────────────────────────────────

const DEFAULTS = { technique: 'auto', model: 'auto' };
const CACHE_DURATION_MS = 24 * 60 * 60 * 1000; // 24 hours

const TIER_LABELS = { flash: 'Flash', pro: 'Pro', latest: 'Latest' };

// ── Boot ──────────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  loadApiKey();
  loadTechnique();
  loadModel();
  loadStats();
  loadCachedModelStatus();
  setupApiKeyListeners();
  setupTechniqueListeners();
  setupModelListeners();
  setupDiscoveryListener();
  setupPlatformLinks();
});

// ── API Key ───────────────────────────────────────────────────────────────────

function loadApiKey() {
  if (!chrome?.storage) return;
  chrome.storage.sync.get(['geminiApiKey'], (result) => {
    if (result.geminiApiKey) {
      document.getElementById('apiKey').value = result.geminiApiKey;
      showStatus('✅ API Key loaded', 'success');
    }
  });
}

function setupApiKeyListeners() {
  const saveBtn  = document.getElementById('saveKey');
  const clearBtn = document.getElementById('clearKey');
  const input    = document.getElementById('apiKey');

  saveBtn?.addEventListener('click', () => {
    const key = input.value.trim();
    if (!key) { showStatus('⚠️ Please paste an API key first', 'error'); return; }
    chrome.storage.sync.set({ geminiApiKey: key }, () => {
      showStatus('✅ API Key saved!', 'success');
      setTimeout(() => showStatus('', ''), 4000);
    });
  });

  clearBtn?.addEventListener('click', () => {
    chrome.storage.sync.remove('geminiApiKey', () => {
      document.getElementById('apiKey').value = '';
      showStatus('🗑️ Key cleared', 'info');
      setTimeout(() => showStatus('', ''), 3000);
    });
  });
}

function showStatus(msg, type) {
  const el = document.getElementById('status');
  if (!el) return;
  el.textContent = msg;
  el.style.color = { success: '#276749', error: '#c53030', info: '#718096' }[type] || '#718096';
}

// ── Technique Picker ──────────────────────────────────────────────────────────

function loadTechnique() {
  chrome.storage.sync.get(['selectedTechnique'], (result) => {
    setActiveChip('techniqueGrid', result.selectedTechnique || DEFAULTS.technique);
  });
}

function setupTechniqueListeners() {
  document.getElementById('techniqueGrid')?.querySelectorAll('.technique-chip').forEach(btn => {
    btn.addEventListener('click', () => {
      const technique = btn.dataset.technique;
      setActiveChip('techniqueGrid', technique);
      chrome.storage.sync.set({ selectedTechnique: technique });
    });
  });
}

function setActiveChip(gridId, value) {
  document.getElementById(gridId)?.querySelectorAll('[data-technique]').forEach(el => {
    el.classList.toggle('active', el.dataset.technique === value);
  });
}

// ── Model Picker ──────────────────────────────────────────────────────────────

function loadModel() {
  chrome.storage.sync.get(['selectedModel'], (result) => {
    setActiveModelCard(result.selectedModel || DEFAULTS.model);
  });
}

function setupModelListeners() {
  document.getElementById('modelGrid')?.querySelectorAll('.model-card').forEach(btn => {
    btn.addEventListener('click', () => {
      const model = btn.dataset.model;
      setActiveModelCard(model);
      chrome.storage.sync.set({ selectedModel: model });
    });
  });
}

function setActiveModelCard(value) {
  document.getElementById('modelGrid')?.querySelectorAll('[data-model]').forEach(el => {
    el.classList.toggle('active', el.dataset.model === value);
  });
}

// ── Model Discovery ───────────────────────────────────────────────────────────

function setupDiscoveryListener() {
  document.getElementById('checkModels')?.addEventListener('click', runModelDiscovery);
}

async function runModelDiscovery() {
  const btn      = document.getElementById('checkModels');
  const iconEl   = document.getElementById('checkModelsIcon');
  const textEl   = document.getElementById('checkModelsText');

  // Need API key
  const stored = await new Promise(r => chrome.storage.sync.get(['geminiApiKey'], r));
  if (!stored.geminiApiKey) {
    showModelStatusError('⚠️ Add your API key first to check model availability.');
    return;
  }

  // Disable button + show spinner
  btn.disabled = true;
  iconEl.textContent = '⏳';
  iconEl.classList.add('spinning');
  textEl.textContent = 'Checking models…';
  showModelStatusChecking();

  try {
    const response = await sendMessage({ action: 'MODEL_DISCOVERY', apiKey: stored.geminiApiKey });

    if (response?.success) {
      const { availability, models, timestamp } = response.data;
      // Cache results
      chrome.storage.local.set({ modelAvailability: availability, modelCheckTimestamp: timestamp, modelMeta: models });
      renderModelStatus(models, availability);
    } else {
      showModelStatusError('❌ Check failed: ' + (response?.error || 'Unknown error'));
    }
  } catch (e) {
    showModelStatusError('❌ Error: ' + e.message);
  } finally {
    btn.disabled = false;
    iconEl.classList.remove('spinning');
    iconEl.textContent = '🔍';
    textEl.textContent = 'Check My Available Models';
  }
}

function loadCachedModelStatus() {
  chrome.storage.local.get(['modelAvailability', 'modelCheckTimestamp', 'modelMeta'], (result) => {
    if (!result.modelAvailability || !result.modelCheckTimestamp) return;

    const age = Date.now() - result.modelCheckTimestamp;
    if (age > CACHE_DURATION_MS) return; // Cache expired

    renderModelStatus(result.modelMeta || [], result.modelAvailability);
    showDiscoveryHint(result.modelCheckTimestamp);
  });
}

function renderModelStatus(models, availability) {
  const grid = document.getElementById('modelStatusGrid');
  if (!grid) return;
  grid.innerHTML = '';

  models.forEach(m => {
    const available = availability[m.id];
    const tierClass = `tier-tag-${m.tier}`;

    const row = document.createElement('div');
    row.className = 'model-status-row';
    row.innerHTML = `
      <span class="model-label">${m.id}</span>
      <span class="model-tier-tag ${tierClass}">${TIER_LABELS[m.tier] || m.tier}</span>
      <span class="model-avail ${available ? 'avail-yes' : 'avail-no'}">
        ${available ? '✅ Available' : '❌ Not found'}
      </span>
    `;
    grid.appendChild(row);
  });
}

function showModelStatusChecking() {
  const grid = document.getElementById('modelStatusGrid');
  if (!grid) return;
  grid.innerHTML = '<div style="text-align:center;font-size:11px;color:#718096;padding:8px;">Probing models, please wait (9 models × ~150ms)…</div>';
}

function showModelStatusError(msg) {
  const grid = document.getElementById('modelStatusGrid');
  if (grid) grid.innerHTML = `<div style="font-size:11px;color:#c53030;padding:6px 0;">${msg}</div>`;
}

function showDiscoveryHint(timestamp) {
  const hint = document.querySelector('.discovery-hint');
  if (hint) {
    const ago = Math.round((Date.now() - timestamp) / 60000);
    hint.textContent = `Last checked: ${ago < 1 ? 'just now' : ago + 'm ago'} · Cached 24h`;
  }
}

// ── Stats ─────────────────────────────────────────────────────────────────────

function loadStats() {
  if (!chrome?.storage) return;
  chrome.storage.local.get(['enhanceCount', 'lastUsed'], (result) => {
    if (result.enhanceCount) renderStats(result);
  });
}

function renderStats(stats) {
  const el = document.getElementById('statsDisplay');
  if (!el || !stats.enhanceCount) return;
  el.innerHTML = `
    <p>📈 <strong>Total Enhancements:</strong> ${stats.enhanceCount}</p>
    ${stats.lastUsed ? `<p>🕐 Last used: ${new Date(stats.lastUsed).toLocaleString()}</p>` : ''}
  `;
}

// ── Platform Links ────────────────────────────────────────────────────────────

function setupPlatformLinks() {
  const map = {
    'platform-chatgpt': 'https://chatgpt.com',
    'platform-gemini':  'https://gemini.google.com',
    'platform-claude':  'https://claude.ai',
  };
  for (const [id, url] of Object.entries(map)) {
    document.getElementById(id)?.addEventListener('click', () => chrome.tabs?.create({ url }));
  }
}

// ── Helper: send message to background ───────────────────────────────────────

function sendMessage(msg) {
  return new Promise((resolve, reject) => {
    if (!chrome.runtime?.id) return reject(new Error('Extension context invalidated'));
    const timer = setTimeout(() => reject(new Error('Request timed out')), 90000);
    chrome.runtime.sendMessage(msg, (response) => {
      clearTimeout(timer);
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(response);
    });
  });
}

// ── Listen for stat updates ───────────────────────────────────────────────────

chrome.runtime?.onMessage.addListener((message) => {
  if (message.type === 'statsUpdate') loadStats();
});
